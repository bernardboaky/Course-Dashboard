package com.example.course_dashboard

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
